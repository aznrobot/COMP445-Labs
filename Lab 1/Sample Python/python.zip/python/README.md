# Requirements
1. Python 3+

# Run echo server

`python echoserver.py --port 8007`

# Run echo client

`python echoclient.py --host localhost --port 8007`

# Run time server

`python timeserver.py --port 8037`

# Run time client

`python timelient.py --host localhost --port 8037`
